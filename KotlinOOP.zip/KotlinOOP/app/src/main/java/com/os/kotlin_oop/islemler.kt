package com.os.kotlin_oop

class islemler {
    fun carpma(a:Int ,b: Int ):Int {
        return a*b
    }
    fun carpma(a:Int,b:Int,c:Int):Int{
        return a*b*c
    }
    fun bolme(a:Int ,b: Int ):Int {
        return a/b
    }
    fun toplama(a:Int ,b: Int ):Int {
        return a+b
    }
    fun cikarma(a:Int ,b: Int ):Int {
        return a-b
    }

}