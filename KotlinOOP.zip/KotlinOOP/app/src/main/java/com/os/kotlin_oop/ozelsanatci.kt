package com.os.kotlin_oop

class ozelsanatci(isim: String, yas: Int, meslek: String) : sanatci(isim, yas, meslek) {
    fun sarkisoyle(){
        println("sarkı söyleniyor")

    }
}