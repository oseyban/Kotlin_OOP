package com.os.kotlin_oop

class Kullanici {
    var isim: String? = null
    var yas: Int? = null

    constructor(isim: String, yas: Int) {
        this.isim=isim
        this.yas= yas
        println("consructor çağrıldı")
    }
    init {
        println("init çağrıldı")
    }
}