package com.os.kotlin_oop

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        println("--------------Sınıflar-----------")
        val kullanici=Kullanici("osman",42)
        val kullanici1=Kullanici("mehmet",45)

        println("--------encapsulation")
        val ahmet=sanatci("ahmet",45,"müzisyen")
        println(ahmet.isim)
        //ahmet.isim="ahmet2"
        println(ahmet.isim)
        println("--------inheritance-------")
        val mehmet=ozelsanatci("mehmet",40,"tiyatrı")
        mehmet.sarkisoyle()
        println("--------inheritance-------")
        val islem=islemler()
        islem.carpma(2,3)       //polymorfizm
        islem.carpma(2,3,4)
        println("--------abstaction-interface-------")

    }
}