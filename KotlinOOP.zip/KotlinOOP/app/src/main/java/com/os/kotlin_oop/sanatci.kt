package com.os.kotlin_oop

open class sanatci(isim:String,yas:Int,meslek:String) {
    //encapsulation


    var isim:String?=isim
            private set
            get

    var yas:Int?=yas
    private set
    get

    private var meslek:String?=meslek


}